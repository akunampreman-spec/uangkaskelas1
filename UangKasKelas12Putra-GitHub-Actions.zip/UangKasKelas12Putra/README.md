# Uang Kas Kelas 12 Putra — Android WebView

Proyek Android Studio yang membuka halaman admin:

`https://kaskelas12putra.vercel.app/admin.html`

## Fitur
- WebView fullscreen tanpa address bar.
- JavaScript dan DOM storage aktif untuk dashboard web.
- Pemilih file Android untuk input unggah bukti/foto pada halaman web.
- Tombol kembali mengikuti riwayat halaman WebView.
- Hanya halaman HTTPS dari `kaskelas12putra.vercel.app` yang dibuka di dalam aplikasi. Tautan web eksternal dibuka di browser.
- Tidak memakai `addJavascriptInterface` dan tidak mengizinkan HTTP biasa.

## Cara build APK di Android Studio
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Buka Android Studio → **Open** → pilih folder `UangKasKelas12Putra` (folder yang berisi `settings.gradle.kts`).
4. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Setelah selesai, klik **locate** pada notifikasi build. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android, lalu buka file APK untuk memasang. Jika Android meminta izin instalasi dari sumber tersebut, ikuti pengaturan keamanan perangkat yang sesuai.

## Membuat APK release untuk dibagikan
Pilih **Build → Generate Signed Bundle / APK → APK**, buat atau pilih keystore milik sendiri, lalu ikuti wizard. Simpan file keystore dan password dengan aman; jangan bagikan keystore.

## Catatan penting
- Aplikasi ini adalah pembungkus website, bukan salinan offline. Internet diperlukan dan perubahan website akan tampil di aplikasi.
- Upload bukti hanya akan berhasil jika fitur unggah di website/backend memang sudah berfungsi. WebView tidak otomatis mengirim bukti ke WhatsApp.
- Pastikan halaman admin memiliki autentikasi dan pembatasan akses yang aman. APK tidak menyembunyikan atau melindungi halaman admin dari orang yang mengetahui URL.
- Sebelum dipakai, uji login, unggah foto, navigasi, dan semua fungsi admin pada perangkat Android.
